local mode, defender = ...
if not Ext.IsServer() or SuccubusDesireTraceStop or (mode ~= 'chain' and mode ~= 'elusive') then
    _P('[SUCC_DESIRE] Open the server console and start one trace in chain or elusive mode.')
    return
end

local mod = 'a41f6c2e-9b37-4d58-b0e1-7c3d95f28e64'
local chain, elusive = 'Passive_Succubus_TM_Chain', 'Passive_Succubus_TM_Elusive'
local extract, resolve = 'Target_Succubus_AirKiss_Extract', 'SUCC_TM_EXTRACT_RESOLVE'
local desire, climax = 'Succubus_Enemy_Desire_Counter', 'Succubus_Enemy_DesireMAX'
local allowed, guard = 'SUCCUBUS_EXTRACTION_ALLOWED', 'SUCCUBUS_EXTRACTION_GUARD'
local wake = 'Projectile_Succubus_EtherealWake'
local auraMark = 'Succubus_Desire_Start_Battle_Mark'
local aura = 'Succubus_Desire_Start_Battle'
local watching = {[desire]=true, [climax]=true, [resolve]=true, [allowed]=true, [guard]=true,
    [auraMark]=true, [aura]=true, SUCC_TM_EXTRACT_CHECK=true, SUCC_TM_KISS_USED=true}
local active, attempt, observer = true, nil, nil

local function read(fn, ...)
    local ok, value = pcall(fn, ...)
    if not ok then return '<query-error>' end
    return value
end
local function key(actor)
    return type(actor) == 'string' and #actor >= 36 and actor:sub(-36):lower() or nil
end
local function display(value)
    if type(value) == 'table' then return read(function() return Ext.Json.Stringify(value) end) end
    return value
end
local function log(event, ...)
    local parts = table.pack(...)
    for i=1,parts.n do parts[i] = tostring(display(parts[i])) end
    _P('[SUCC_DESIRE] ' .. event .. ' ' .. table.concat(parts, ' ', 1, parts.n))
end
local function state(phase, actor, label)
    log(phase, label, 'stat=', read(Osi.GetStatString, actor), 'hp=', read(Osi.GetHitpoints, actor),
        'maxHP=', read(Osi.GetMaxHitpoints, actor), 'dead=', read(Osi.IsDead, actor),
        'inCombat=', read(Osi.IsInCombat, actor), 'desire=', read(Osi.GetStatusTurns, actor, desire),
        'seconds=', read(Osi.GetStatusCurrentLifetime, actor, desire),
        'hasDesire=', read(Osi.HasActiveStatus, actor, desire), 'climax=', read(Osi.HasActiveStatus, actor, climax),
        'auraMark=', read(Osi.HasActiveStatus, actor, auraMark), 'aura=', read(Osi.HasActiveStatus, actor, aura))
end
local function snapshot(phase)
    for _, row in ipairs(attempt.actors) do state(phase, row.actor, row.label) end
    if mode == 'chain' then
        log(phase, 'chain=', read(Osi.HasPassive, attempt.caster, chain),
            'allowed=', read(Osi.HasActiveStatus, attempt.victim, allowed),
            'guard=', read(Osi.HasActiveStatus, attempt.victim, guard),
            'discipline=', read(Osi.GetActionResourceValuePersonal, attempt.caster, 'Reason', 0))
    end
end
local function add(actor, label)
    attempt.labels[key(actor)] = label
    table.insert(attempt.actors, {actor=actor, label=label})
end
local function track(caster, victim)
    attempt = {caster=caster, victim=victim, actors={}, labels={}}
    add(caster, mode == 'chain' and 'caster' or 'defender')
    if victim then add(victim, 'victim') end
    local combat = read(Osi.CombatGetGuidFor, caster)
    local rows = read(function() return Osi.DB_Is_InCombat:Get(nil, combat) end)
    if type(rows) ~= 'table' or not key(combat) then log('participants-unavailable'); return end
    for _, row in ipairs(rows) do
        local actor = row[1]
        if key(actor) and not attempt.labels[key(actor)] and read(Osi.IsDead, actor) == 0 then
            local enemy = read(Osi.IsEnemy, caster, actor)
            local distance = victim and read(Osi.GetDistanceTo, victim, actor)
            if (victim and type(distance) == 'number' and distance <= 6) or (not victim and enemy == 1) then
                local label = (victim and 'nearby' or 'enemy') .. (#attempt.actors + 1)
                add(actor, label)
                if victim then log('nearby', label, 'distance=', distance, 'enemy=', enemy) end
            end
        end
    end
end
local function stop()
    if not active then return end
    if attempt then snapshot('after') end
    active = false
    SuccubusDesireTraceStop = nil
    if observer then Ext.Events.ExecuteFunctor:Unsubscribe(observer) end
    log('END')
end

if mode == 'elusive' then
    defender = defender or read(Osi.GetHostCharacter)
    if not key(defender) or read(Osi.HasPassive, defender, elusive) ~= 1 or read(Osi.IsInCombat, defender) ~= 1 then
        log('Select an in-combat Elusive character. Use its UUID as the second argument if it is not the host.')
        return
    end
    track(defender)
end

Ext.Osiris.RegisterListener('UsingSpellOnTarget',6,'before',function(caster,target,spell,_,_,action)
    if not active then return end
    if mode == 'chain' and not attempt and spell == extract and key(caster) and key(target) then
        track(caster, target)
        attempt.action = action
        log('UsingSpellOnTarget', spell, 'action=', action)
        snapshot('before')
        Ext.Timer.WaitFor(5000, stop)
    elseif mode == 'elusive' and key(target) == key(defender) then
        log('UsingSpellOnTarget', attempt.labels[key(caster)] or 'other', spell, 'action=', action)
    end
end)
for _, event in ipairs({'CastedSpell','CastSpellFailed'}) do
    Ext.Osiris.RegisterListener(event,5,'before',function(caster,spell,_,_,action)
        if active and attempt and mode == 'chain' and spell == extract and action == attempt.action and key(caster) == key(attempt.caster) then
            log(event, spell, 'action=', action)
        end
    end)
end
for _, event in ipairs({'StatusAttempt','StatusAttemptFailed','StatusApplied','StatusRemoved'}) do
    Ext.Osiris.RegisterListener(event,4,event == 'StatusAttempt' and 'before' or 'after',function(target,name,source,action)
        if not active or not attempt or not watching[name] then return end
        local label, cause = attempt.labels[key(target)], attempt.labels[key(source)]
        if not label and not cause then return end
        log(event, label or 'other', name, 'source=', cause or 'other', 'action=', action)
        if name == desire or name == climax then state(event, target, label or 'other') end
    end)
end
Ext.Osiris.RegisterListener('AttackedBy',7,'after',function(target,_,attacker,kind,damage,cause,action)
    if not active or not attempt then return end
    if key(target) == key(attempt.victim or defender) then
        log('AttackedBy', attempt.labels[key(attacker)] or 'other', kind, damage, cause, 'action=', action)
    end
end)
if mode == 'elusive' then
    local function same_combat(actor)
        local combat = key(read(Osi.CombatGetGuidFor, defender))
        return combat ~= nil and combat == key(read(Osi.CombatGetGuidFor, actor))
    end
    Ext.Osiris.RegisterListener('ReactionInterruptActionNeeded',1,'after',function(actor)
        if not active or not same_combat(actor) then return end
        attempt.pendingReaction = true
        log('ReactionInterruptActionNeeded', attempt.labels[key(actor)] or 'other', 'stat=', read(Osi.GetStatString, actor))
        snapshot('reaction-pending')
    end)
    Ext.Osiris.RegisterListener('ReactionInterruptUsed',3,'after',function(actor, reaction, automatic)
        if not active or not same_combat(actor) then return end
        log('ReactionInterruptUsed', attempt.labels[key(actor)] or 'other', reaction, 'automatic=', automatic)
        snapshot('reaction-used')
    end)
    Ext.Osiris.RegisterListener('TurnStarted',1,'after',function(actor)
        if not active or not (attempt.pendingReaction or attempt.miss) or not same_combat(actor) then return end
        log('TurnStarted', attempt.labels[key(actor)] or 'other', 'stat=', read(Osi.GetStatString, actor))
        snapshot('new-turn')
        attempt.pendingReaction, attempt.miss = false, false
    end)
    Ext.Osiris.RegisterListener('MissedBy',4,'after',function(target,owner,attacker,action)
        if not active or key(target) ~= key(defender) then return end
        local id = key(attacker)
        if id and not attempt.labels[id] then add(attacker, 'attacker' .. (#attempt.actors + 1)) end
        attempt.miss = true
        local label = attempt.labels[id] or 'other'
        log('MissedBy', 'defender', 'attacker=', label, 'owner=', attempt.labels[key(owner)] or 'other', 'action=', action)
        if id then state('miss', attacker, label) end
    end)
end

local function field(context, name) return read(function() return context[name] end) end
local ok, value = pcall(function()
    return Ext.Events.ExecuteFunctor:Subscribe(function(event)
        if not active or not attempt then return end
        local context = event.Params
        local id = mode == 'chain' and field(context, 'StatusId') or field(context, 'PassiveId')
        if id == resolve or id == elusive then
            log('ExecuteFunctor', id, 'context=', field(context, 'Type'),
                'action=', field(context, 'StoryActionId'), 'hitFlags=', field(field(context, 'Hit'), 'EffectFlags'))
        end
    end)
end)
if ok then observer = value end
local version = read(function() return Ext.Mod.GetMod(mod).Info.ModVersion end)
local function stat(id, name) return read(function() return Ext.Stats.Get(id)[name] end) end
log('READY', mode, 'modVersion=', version, 'SE=', read(Ext.Utils.Version), 'functorHook=', ok)
if mode == 'chain' then
    log('activeStats', 'wakeTargets=', stat(wake, 'TargetConditions'), 'trajectory=', stat(wake, 'Trajectories'))
else
    log('activeStats', stat(elusive, 'StatsFunctorContext'), stat(elusive, 'Conditions'),
        'functors=', stat(elusive, 'StatsFunctors'), 'stacks=', stat(desire, 'StackType'), 'remove=', stat(desire, 'RemoveConditions'))
    snapshot('before')
end
SuccubusDesireTraceStop = stop
Ext.Timer.WaitFor(45000, stop)
